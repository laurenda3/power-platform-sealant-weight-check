import React, { useState, useEffect, useMemo } from "react";
import {
    Text,
    Button,
    Input,
    Divider,
    makeStyles,
    tokens,
} from "@fluentui/react-components";
import { DismissRegular, InfoRegular } from "@fluentui/react-icons";
import type { GeneratedComponentProps, ReadableTableRow, WritableTableRow, TableRegistrations, EnumRegistrations } from "./RuntimeTypes";

// Localization: Language map (add more if you support other languages)
const langMap: Record<number, { code: string; name: string; isRtl: boolean }> = {
    1033: { code: "en-US", name: "English (United States)", isRtl: false },
};

// Localization: Translations (can expand for more languages)
const translations: Record<string, Record<string, string>> = {
    "en-US": {
        lauland: "Lauland Development",
        sheetTitle: "Sealant and Potting Calculation Sheet",
        formNumber: "Form Number LL-002",
        revisionDate: "Revision Date 10/19/2026",
        line: "LINE",
        frameSize: "FRAME SIZE",
        date: "DATE",
        shift: "SHIFT",
        submit: "Submit",
        clear: "Clear",
        successMsg: "Form submitted successfully.",
        errorMsg: "Save failed. Please try again.",
        sealantCalculations: "Sealant Calculations",
        frameMachine1: "Framing Machine 1 Sealant",
        frameMachine2: "Framing Machine 2 Sealant",
        junctionBoxSealant: "Junction Box Sealant",
        longFrame1: "Long Frame 1",
        shortFrame1: "Short Frame 1",
        shortFrame2: "Short Frame 2",
        longFrame2: "Long Frame 2",
        emptyCupWeight: "Empty Cup Weight (g)",
        filledCupWeight: "Filled Cup Weight (g)",
        netWeightSealent: "Net Weight of Sealant (g)",
        positive: "Positive",
        middle: "Middle",
        negative: "Negative",
        junctionBoxPotting: "Junction Box Potting",
        positiveTerminal: "Positive Terminal",
        middleTerminal: "Middle Terminal",
        negativeTerminal: "Negative Terminal",
        pottingWeight: "Potting Weight (g)",
        baseWeight: "Base Weight (g)",
        catalyst: "Catalyst (g)",
        netWeightPotting: "Net Weight of Potting (g)",
        ratio: "Ratio",
        selectLine: "Select line",
        selectSize: "Select frame size",
        selectShift: "Select shift",
        selectDate: "Select date",
        required: "Required",
        gUnit: "g",
    },
};

const useStyles = makeStyles({
    root: {
        width: "100%",
        height: "100vh",
        padding: tokens.spacingVerticalL,
        backgroundColor: tokens.colorNeutralBackground1,
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        overflowY: "auto",
        paddingBottom: "200px", // Added for scrollable bottom space
    },
    paper: {
        background: tokens.colorNeutralBackground1,
        borderRadius: tokens.borderRadiusLarge,
        boxShadow: tokens.shadow8,
        padding: tokens.spacingVerticalXXL,
        margin: "0 auto",
        width: "100%",
        maxWidth: 1200,
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        gap: tokens.spacingVerticalL,
    },
    titleRow: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: tokens.spacingVerticalL,
        flexWrap: "wrap",
    },
    headerRow: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: tokens.spacingVerticalL,
        gap: tokens.spacingHorizontalXL,
        flexWrap: "wrap",
    },
    headerGroup: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        gap: tokens.spacingHorizontalM,
        minWidth: 180,
        marginInlineEnd: tokens.spacingHorizontalXL,
    },
    sectionTitle: {
        margin: `${tokens.spacingVerticalL} 0 ${tokens.spacingVerticalM} 0`,
        fontSize: tokens.fontSizeHero700,
        fontWeight: tokens.fontWeightSemibold as any,
        lineHeight: tokens.lineHeightHero700,
        textAlign: "center",
    },
    blockRow: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        gap: tokens.spacingHorizontalXXL,
        flexWrap: "nowrap",
        marginBottom: tokens.spacingVerticalL,
        marginTop: tokens.spacingVerticalL,
    },
    block: {
        background: tokens.colorNeutralBackground2,
        borderRadius: tokens.borderRadiusMedium,
        boxShadow: tokens.shadow4,
        padding: tokens.spacingVerticalXL,
        flex: "1 1 0",
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "stretch",
    },
    tblHeader: {
        display: "grid",
        gridTemplateColumns: "110px 1fr 1fr 1fr",
        gap: "8px",
        fontWeight: tokens.fontWeightSemibold as any,
        marginBottom: tokens.spacingVerticalMNudge,
    },
    tblRow: {
        display: "grid",
        gridTemplateColumns: "110px 1fr 1fr 1fr",
        gap: "8px",
        alignItems: "center",
        marginBottom: tokens.spacingVerticalMNudge,
    },
    cellLabel: {
        flex: "0 0 110px",
        minWidth: 110,
        maxWidth: 110,
        fontWeight: tokens.fontWeightSemibold as any,
        fontSize: tokens.fontSizeBase400,
        textAlign: "left" as const,
        paddingRight: tokens.spacingHorizontalS,
        whiteSpace: "nowrap",
        alignSelf: "center",
    },
    cell: {
        display: "flex",
        alignItems: "center",
        width: "100%",
        minWidth: 0,
        maxWidth: "none",
    },
    cellInput: {
        flex: "1 1 auto",
        minWidth: "60px",
        width: "100%",
        borderRadius: tokens.borderRadiusSmall,
        marginRight: tokens.spacingHorizontalXS,
    },
    cellUnit: {
        width: "24px",
        minWidth: "24px",
        maxWidth: "24px",
        marginLeft: tokens.spacingHorizontalXS,
        fontWeight: tokens.fontWeightRegular as any,
        textAlign: "left",
        fontSize: tokens.fontSizeBase300,
    },
    netCell: {
        width: "100%",
        minWidth: 0,
        maxWidth: "none",
        minHeight: "32px",
        textAlign: "center" as const,
        borderRadius: tokens.borderRadiusSmall,
        fontWeight: tokens.fontWeightRegular as any,
        background: tokens.colorNeutralBackground1,
        transition: "background 0.3s, color 0.3s",
        padding: `${tokens.spacingVerticalSNudge} ${tokens.spacingHorizontalS}`,
        boxSizing: "border-box",
        border: `1px solid ${tokens.colorNeutralStroke1}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
    },
    outOfTolCell: {
        background: "#FFC7CE",
        color: "#9C0006",
        fontWeight: tokens.fontWeightBold as any,
        border: `1px solid #9C0006`,
    },
    ratioCell: {
        minWidth: 90,
        minHeight: "32px",
        textAlign: "center" as const,
        borderRadius: tokens.borderRadiusSmall,
        fontWeight: tokens.fontWeightRegular as any,
        background: tokens.colorNeutralBackground1,
        transition: "background 0.3s, color 0.3s",
        padding: `${tokens.spacingVerticalSNudge} ${tokens.spacingHorizontalXS}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
    },
    redBold: {
        color: "#9C0006",
        fontWeight: tokens.fontWeightBold as any,
    },
    btnRow: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "flex-end",
        gap: tokens.spacingHorizontalL,
        marginTop: tokens.spacingVerticalXL,
    },
    message: {
        marginTop: tokens.spacingVerticalL,
        padding: tokens.spacingVerticalM,
        borderRadius: tokens.borderRadiusMedium,
        background: tokens.colorStatusSuccessBackground1,
        color: tokens.colorStatusSuccessForeground1,
        border: `1px solid ${tokens.colorStatusSuccessBorder1}`,
        fontSize: tokens.fontSizeBase400,
        textAlign: "center" as const,
        minWidth: 180,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: tokens.spacingHorizontalS,
    },
    errorMessage: {
        marginTop: tokens.spacingVerticalL,
        padding: tokens.spacingVerticalM,
        borderRadius: tokens.borderRadiusMedium,
        background: tokens.colorStatusDangerBackground1,
        color: tokens.colorStatusDangerForeground1,
        fontSize: tokens.fontSizeBase400,
        textAlign: "center" as const,
        minWidth: 180,
    },
    htmlSelect: {
        minWidth: 120,
        padding: "6px 8px",
        borderRadius: tokens.borderRadiusSmall,
        border: `1px solid ${tokens.colorNeutralStroke1}`,
        fontSize: tokens.fontSizeBase400,
        fontFamily: tokens.fontFamilyBase,
        background: tokens.colorNeutralBackground1,
        color: tokens.colorNeutralForeground1,
    },
});

// ---- Utility: Date helpers, number formatting ----
const todayIsoString = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const formatWeight = (value: number | null | undefined) =>
    value === null || value === undefined || isNaN(value)
        ? ""
        : `${value.toFixed(2)} g`;

const formatWeightZero = (value: number | null | undefined) =>
    value === null || value === undefined || isNaN(value)
        ? ""
        : `${value.toFixed(2)} g`;

const formatRatio = (value: number | null | undefined) =>
    value === null || value === undefined || isNaN(value)
        ? ""
        : value.toFixed(2);

const toNumber2Dec = (value: string | number | null | undefined) => {
    if (typeof value === "number") return Number(value);
    if (typeof value === "string" && value.trim() !== "") {
        const n = Number(value);
        return isNaN(n) ? null : Math.round(n * 100) / 100;
    }
    return null;
};

// ---- Section/block/row definitions ----
const lineOptions = ["1", "2", "3", "4"];
const shiftOptions = ["A", "B", "C", "D"];

// Block and row definitions for rendering
const frameSealantRows = [
    { key: "longFrame1", label: "Long Frame 1" },
    { key: "shortFrame1", label: "Short Frame 1" },
    { key: "shortFrame2", label: "Short Frame 2" },
    { key: "longFrame2", label: "Long Frame 2" },
];

const jbSealantRows = [
    { key: "positive", label: "Positive" },
    { key: "middle", label: "Middle" },
    { key: "negative", label: "Negative" },
];

// Potting block definitions
const pottingRows = [
    { key: "potting", label: "Potting Weight (g)" },
    { key: "base", label: "Base Weight (g)" },
    { key: "catalyst", label: "Catalyst (g)" }
];

// Definitions for where to read tolerance values
const toleranceChecks = {
    longFrame: { check: "Long Frame" },
    shortFrame: { check: "Short Frame" },
    jbPositive: { check: "JB Positive" },
    jbMiddle: { check: "JB Middle" },
    jbNegative: { check: "JB Negative" },
    pottingRatio: { check: "Potting Ratio" },
};

// --- Main Component ---
const GeneratedComponent = ({ dataApi }: GeneratedComponentProps) => {
    // Localization hooks
    const language = useMemo(() => {
        const uiLanguageId =
            (typeof Xrm !== "undefined" &&
                Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) ||
            1033;
        return langMap[uiLanguageId]?.code || "en-US";
    }, []);
    const isRTL = useMemo(() => {
        const uiLanguageId =
            (typeof Xrm !== "undefined" &&
                Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) ||
            1033;
        return langMap[uiLanguageId]?.isRtl || false;
    }, []);
    const t = (key: string) =>
        translations[language]?.[key] || translations["en-US"]?.[key] || key;

    const styles = useStyles();

    // --- Header fields ---
    const [line, setLine] = useState<number | null>(null);
    const [frameSize, setFrameSize] = useState<number | null>(null);
    const [date, setDate] = useState<string>(todayIsoString());
    const [shift, setShift] = useState<string | null>(null);

    // --- Frame size options, loaded from Sealant Tolerances ---
    const [frameSizeOptions, setFrameSizeOptions] = useState<number[]>([]);
    // --- Tolerance records ---
    const [tolerances, setTolerances] = useState<
        ReadableTableRow<TableRegistrations["craf4_sealanttolerances"]>[]
    >([]);
    useEffect(() => {
        if (dataApi) {
            (async () => {
                const result = await dataApi.queryTable("craf4_sealanttolerances", {
                    select: [
                        "craf4_checktype",
                        "craf4_framesize",
                        "craf4_framelengthmm",
                        "craf4_maximumvalue",
                        "craf4_minimumvalue",
                    ],
                    filter: "",
                    pageSize: 100,
                });
                setTolerances(result.rows);
                const sizes = Array.from(
                    new Set(
                        result.rows
                            .map((r) => r.craf4_framesize)
                            .filter((s) => typeof s === "number" && s > 0)
                    )
                );
                setFrameSizeOptions(sizes);
            })();
        }
    }, [dataApi]);

    // ---- Inputs state: Store values for all editable cells ----
    const [fm1Inputs, setFm1Inputs] = useState<Record<string, { empty: string; filled: string }>>(
        () =>
            Object.fromEntries(
                frameSealantRows.map((row) => [
                    row.key,
                    { empty: "", filled: "" },
                ])
            )
    );
    const [fm2Inputs, setFm2Inputs] = useState<Record<string, { empty: string; filled: string }>>(
        () =>
            Object.fromEntries(
                frameSealantRows.map((row) => [
                    row.key,
                    { empty: "", filled: "" },
                ])
            )
    );
    const [jbInputs, setJbInputs] = useState<Record<string, { empty: string; filled: string }>>(
        () =>
            Object.fromEntries(
                jbSealantRows.map((row) => [
                    row.key,
                    { empty: "", filled: "" },
                ])
            )
    );
    const [pottingInputs, setPottingInputs] = useState<
        Record<"positive" | "middle" | "negative", Record<string, { empty: string; filled: string }>>
    >(() => ({
        positive: Object.fromEntries(
            pottingRows.map((row) => [row.key, { empty: "", filled: "" }])
        ),
        middle: Object.fromEntries(
            pottingRows.map((row) => [row.key, { empty: "", filled: "" }])
        ),
        negative: Object.fromEntries(
            pottingRows.map((row) => [row.key, { empty: "", filled: "" }])
        ),
    }));

    function calcNet(filled: string, empty: string): number | null {
        const f = toNumber2Dec(filled);
        const e = toNumber2Dec(empty);
        if (f === null || e === null) return null;
        return Math.round((f - e) * 100) / 100;
    }
    function calcRatio(baseNet: number | null, catalystNet: number | null): number | null {
        if (
            catalystNet === null ||
            catalystNet === 0 ||
            baseNet === null ||
            baseNet === undefined
        )
            return null;
        return Math.round((baseNet / catalystNet) * 100) / 100;
    }

    // FIX: Compare frame size and check name with type-safe conversions
    function getTolerance(checkType: string, frameSize: number | null): { min: number | null, max: number | null } {
        const record =
            frameSize && frameSize > 0
                ? tolerances.find(
                      (t) =>
                          Number(t.craf4_framesize) === Number(frameSize) &&
                          String(t.craf4_checktype).trim() === checkType
                  )
                : tolerances.find(
                      (t) => Number(t.craf4_framesize) === 0 && String(t.craf4_checktype).trim() === checkType
                  );
        return {
            min: record?.craf4_minimumvalue ?? null,
            max: record?.craf4_maximumvalue ?? null,
        };
    }

    function isOutOfTolerance(
        value: number | null | undefined,
        tolerance: { min: number | null; max: number | null },
        filledInput: string
    ): boolean {
        if (
            value === null ||
            value === undefined ||
            tolerance.min === null ||
            tolerance.max === null ||
            filledInput === ""
        )
            return false;
        return value < tolerance.min || value > tolerance.max;
    }

    const [submitting, setSubmitting] = useState(false);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");
    const isReadyToSubmit =
        !!line && !!frameSize && !!shift && !!date && !submitting;

    function handleClear() {
        setLine(null);
        setFrameSize(null);
        setDate(todayIsoString());
        setShift(null);
        setFm1Inputs(
            Object.fromEntries(
                frameSealantRows.map((row) => [
                    row.key,
                    { empty: "", filled: "" },
                ])
            )
        );
        setFm2Inputs(
            Object.fromEntries(
                frameSealantRows.map((row) => [
                    row.key,
                    { empty: "", filled: "" },
                ])
            )
        );
        setJbInputs(
            Object.fromEntries(
                jbSealantRows.map((row) => [
                    row.key,
                    { empty: "", filled: "" },
                ])
            )
        );
        setPottingInputs({
            positive: Object.fromEntries(
                pottingRows.map((row) => [row.key, { empty: "", filled: "" }])
            ),
            middle: Object.fromEntries(
                pottingRows.map((row) => [row.key, { empty: "", filled: "" }])
            ),
            negative: Object.fromEntries(
                pottingRows.map((row) => [row.key, { empty: "", filled: "" }])
            ),
        });
        setSuccessMessage("");
        setErrorMessage("");
    }

    // --- Updated handleSubmit with out-of-tolerance tracking ---
    async function handleSubmit() {
        if (!isReadyToSubmit || !dataApi) return;
        setSubmitting(true);
        setErrorMessage("");
        setSuccessMessage("");

        const frameMachineNetWeights = Object.fromEntries(
            frameSealantRows.map((row) => [
                row.key,
                calcNet(fm1Inputs[row.key].filled, fm1Inputs[row.key].empty),
            ])
        );
        const frameMachine2NetWeights = Object.fromEntries(
            frameSealantRows.map((row) => [
                row.key,
                calcNet(fm2Inputs[row.key].filled, fm2Inputs[row.key].empty),
            ])
        );
        const jbSealantNetWeights = Object.fromEntries(
            jbSealantRows.map((row) => [
                row.key,
                calcNet(jbInputs[row.key].filled, jbInputs[row.key].empty),
            ])
        );
        const pottingNetWeights = {
            positive: Object.fromEntries(
                pottingRows.map((row) => [
                    row.key,
                    calcNet(
                        pottingInputs.positive[row.key].filled,
                        pottingInputs.positive[row.key].empty
                    ),
                ])
            ),
            middle: Object.fromEntries(
                pottingRows.map((row) => [
                    row.key,
                    calcNet(
                        pottingInputs.middle[row.key].filled,
                        pottingInputs.middle[row.key].empty
                    ),
                ])
            ),
            negative: Object.fromEntries(
                pottingRows.map((row) => [
                    row.key,
                    calcNet(
                        pottingInputs.negative[row.key].filled,
                        pottingInputs.negative[row.key].empty
                    ),
                ])
            ),
        };
        const ratioPositive = calcRatio(
            pottingNetWeights.positive.base,
            pottingNetWeights.positive.catalyst
        );
        const ratioMiddle = calcRatio(
            pottingNetWeights.middle.base,
            pottingNetWeights.middle.catalyst
        );
        const ratioNegative = calcRatio(
            pottingNetWeights.negative.base,
            pottingNetWeights.negative.catalyst
        );

        // --- Out-of-tolerance tracking ---
        const outOfTolLines: string[] = [];

        // FM1 nets
        frameSealantRows.forEach((row) => {
            const net = frameMachineNetWeights[row.key];
            const filled = fm1Inputs[row.key].filled;
            let tolCheck = row.key.startsWith("long")
                ? toleranceChecks.longFrame.check
                : toleranceChecks.shortFrame.check;
            const tolerance =
                frameSize && filled !== ""
                    ? getTolerance(tolCheck, frameSize)
                    : { min: null, max: null };
            if (
                filled !== "" &&
                tolerance.min !== null &&
                tolerance.max !== null &&
                isOutOfTolerance(net, tolerance, filled)
            ) {
                outOfTolLines.push(
                    `FM1 ${row.label}: ${net?.toFixed(2)} g (limit ${tolerance.min?.toFixed(2)} to ${tolerance.max?.toFixed(2)} g)`
                );
            }
        });

        // FM2 nets
        frameSealantRows.forEach((row) => {
            const net = frameMachine2NetWeights[row.key];
            const filled = fm2Inputs[row.key].filled;
            let tolCheck = row.key.startsWith("long")
                ? toleranceChecks.longFrame.check
                : toleranceChecks.shortFrame.check;
            const tolerance =
                frameSize && filled !== ""
                    ? getTolerance(tolCheck, frameSize)
                    : { min: null, max: null };
            if (
                filled !== "" &&
                tolerance.min !== null &&
                tolerance.max !== null &&
                isOutOfTolerance(net, tolerance, filled)
            ) {
                outOfTolLines.push(
                    `FM2 ${row.label}: ${net?.toFixed(2)} g (limit ${tolerance.min?.toFixed(2)} to ${tolerance.max?.toFixed(2)} g)`
                );
            }
        });

        // JB nets
        jbSealantRows.forEach((row) => {
            const net = jbSealantNetWeights[row.key];
            const filled = jbInputs[row.key].filled;
            let tolCheck =
                row.key === "positive"
                    ? toleranceChecks.jbPositive.check
                    : row.key === "middle"
                    ? toleranceChecks.jbMiddle.check
                    : toleranceChecks.jbNegative.check;
            const tolerance =
                filled !== ""
                    ? getTolerance(tolCheck, 0)
                    : { min: null, max: null };
            if (
                filled !== "" &&
                tolerance.min !== null &&
                tolerance.max !== null &&
                isOutOfTolerance(net, tolerance, filled)
            ) {
                outOfTolLines.push(
                    `JB ${row.label}: ${net?.toFixed(2)} g (limit ${tolerance.min?.toFixed(2)} to ${tolerance.max?.toFixed(2)} g)`
                );
            }
        });

        // Potting Ratios
        [
            { key: "positive", label: "Positive", ratio: ratioPositive, nets: pottingNetWeights.positive, inputs: pottingInputs.positive },
            { key: "middle", label: "Middle", ratio: ratioMiddle, nets: pottingNetWeights.middle, inputs: pottingInputs.middle },
            { key: "negative", label: "Negative", ratio: ratioNegative, nets: pottingNetWeights.negative, inputs: pottingInputs.negative },
        ].forEach((item) => {
            // Only check if catalyst filled is entered
            const catalystFilled = item.inputs.catalyst.filled;
            const tolerance = catalystFilled !== "" ? getTolerance(toleranceChecks.pottingRatio.check, 0) : { min: null, max: null };
            if (
                catalystFilled !== "" &&
                tolerance.min !== null &&
                tolerance.max !== null &&
                isOutOfTolerance(item.ratio, tolerance, catalystFilled)
            ) {
                outOfTolLines.push(
                    `${item.label} Ratio: ${item.ratio?.toFixed(2)} (limit ${tolerance.min?.toFixed(2)} to ${tolerance.max?.toFixed(2)})`
                );
            }
        });

        // Parse date string "YYYY-MM-DD" and build Date object as local noon
        let measurementDate: Date | null = null;
        if (date && typeof date === "string") {
            const parts = date.split("-");
            if (parts.length === 3) {
                const year = Number(parts[0]);
                const month = Number(parts[1]);
                const day = Number(parts[2]);
                if (
                    !isNaN(year) &&
                    !isNaN(month) &&
                    !isNaN(day)
                ) {
                    measurementDate = new Date(year, month - 1, day, 12, 0, 0);
                }
            }
        }

        const payload: WritableTableRow<TableRegistrations["craf4_sealantlog"]> & {
            craf4_outoftolerancecount?: number;
            craf4_outoftolerancedetails?: string | null;
        } = {
            craf4_shiftidentifier: shift!,
            craf4_framesize: frameSize!,
            craf4_measurementdate: measurementDate!,
            craf4_productionlinenumber: Number(line),
            craf4_fm1longframe1emptycupweight: toNumber2Dec(fm1Inputs.longFrame1.empty) ?? null,
            craf4_fm1longframe1filledcupweight: toNumber2Dec(fm1Inputs.longFrame1.filled) ?? null,
            craf4_fm1longframe1netweight: frameMachineNetWeights.longFrame1 ?? null,
            craf4_fm1shortframe1emptycupweight: toNumber2Dec(fm1Inputs.shortFrame1.empty) ?? null,
            craf4_fm1shortframe1filledcupweight: toNumber2Dec(fm1Inputs.shortFrame1.filled) ?? null,
            craf4_fm1shortframe1netweight: frameMachineNetWeights.shortFrame1 ?? null,
            craf4_fm1shortframe2emptycupweight: toNumber2Dec(fm1Inputs.shortFrame2.empty) ?? null,
            craf4_fm1shortframe2filledcupweight: toNumber2Dec(fm1Inputs.shortFrame2.filled) ?? null,
            craf4_fm1shortframe2netweight: frameMachineNetWeights.shortFrame2 ?? null,
            craf4_fm1longframe2emptycupweight: toNumber2Dec(fm1Inputs.longFrame2.empty) ?? null,
            craf4_fm1longframe2filledcupweight: toNumber2Dec(fm1Inputs.longFrame2.filled) ?? null,
            craf4_fm1longframe2netweight: frameMachineNetWeights.longFrame2 ?? null,

            craf4_fm2longframe1emptycupweight: toNumber2Dec(fm2Inputs.longFrame1.empty) ?? null,
            craf4_fm2longframe1filledcupweight: toNumber2Dec(fm2Inputs.longFrame1.filled) ?? null,
            craf4_fm2longframe1netweight: frameMachine2NetWeights.longFrame1 ?? null,
            craf4_fm2shortframe1emptycupweight: toNumber2Dec(fm2Inputs.shortFrame1.empty) ?? null,
            craf4_fm2shortframe1filledcupweight: toNumber2Dec(fm2Inputs.shortFrame1.filled) ?? null,
            craf4_fm2shortframe1netweight: frameMachine2NetWeights.shortFrame1 ?? null,
            craf4_fm2shortframe2emptycupweight: toNumber2Dec(fm2Inputs.shortFrame2.empty) ?? null,
            craf4_fm2shortframe2filledcupweight: toNumber2Dec(fm2Inputs.shortFrame2.filled) ?? null,
            craf4_fm2shortframe2netweight: frameMachine2NetWeights.shortFrame2 ?? null,
            craf4_fm2longframe2emptycupweight: toNumber2Dec(fm2Inputs.longFrame2.empty) ?? null,
            craf4_fm2longframe2filledcupweight: toNumber2Dec(fm2Inputs.longFrame2.filled) ?? null,
            craf4_fm2longframe2netweight: frameMachine2NetWeights.longFrame2 ?? null,

            craf4_jbsealantpositiveemptycupweight: toNumber2Dec(jbInputs.positive.empty) ?? null,
            craf4_jbsealantpositivefilledcupweight: toNumber2Dec(jbInputs.positive.filled) ?? null,
            craf4_jbsealantpositivenetweight: jbSealantNetWeights.positive ?? null,
            craf4_jbsealantmiddleemptycupweight: toNumber2Dec(jbInputs.middle.empty) ?? null,
            craf4_jbsealantmiddlefilledcupweight: toNumber2Dec(jbInputs.middle.filled) ?? null,
            craf4_jbsealantmiddlenetweight: jbSealantNetWeights.middle ?? null,
            craf4_jbsealantnegativeemptycupweight: toNumber2Dec(jbInputs.negative.empty) ?? null,
            craf4_jbsealantnegativefilledcupweight: toNumber2Dec(jbInputs.negative.filled) ?? null,
            craf4_jbsealantnegativenetweight: jbSealantNetWeights.negative ?? null,

            craf4_positivepottingemptycupweight: toNumber2Dec(pottingInputs.positive.potting.empty) ?? null,
            craf4_positivepottingfilledcupweight: toNumber2Dec(pottingInputs.positive.potting.filled) ?? null,
            craf4_positivepottingnetweight: pottingNetWeights.positive.potting ?? null,
            craf4_positivebaseemptycupweight: toNumber2Dec(pottingInputs.positive.base.empty) ?? null,
            craf4_positivebasefilledcupweight: toNumber2Dec(pottingInputs.positive.base.filled) ?? null,
            craf4_positivebasenetweight: pottingNetWeights.positive.base ?? null,
            craf4_positivecatalystemptycupweight: toNumber2Dec(pottingInputs.positive.catalyst.empty) ?? null,
            craf4_positivecatalystfilledcupweight: toNumber2Dec(pottingInputs.positive.catalyst.filled) ?? null,
            craf4_positivecatalystnetweight: pottingNetWeights.positive.catalyst ?? null,
            craf4_positiveratio: ratioPositive ?? null,

            craf4_middlepottingemptycupweight: toNumber2Dec(pottingInputs.middle.potting.empty) ?? null,
            craf4_middlepottingfilledcupweight: toNumber2Dec(pottingInputs.middle.potting.filled) ?? null,
            craf4_middlepottingnetweight: pottingNetWeights.middle.potting ?? null,
            craf4_middlebaseemptycupweight: toNumber2Dec(pottingInputs.middle.base.empty) ?? null,
            craf4_middlebasefilledcupweight: toNumber2Dec(pottingInputs.middle.base.filled) ?? null,
            craf4_middlebasenetweight: pottingNetWeights.middle.base ?? null,
            craf4_middlecatalystemptycupweight: toNumber2Dec(pottingInputs.middle.catalyst.empty) ?? null,
            craf4_middlecatalystfilledcupweight: toNumber2Dec(pottingInputs.middle.catalyst.filled) ?? null,
            craf4_middlecatalystnetweight: pottingNetWeights.middle.catalyst ?? null,
            craf4_middleratio: ratioMiddle ?? null,

            craf4_negativepottingemptycupweight: toNumber2Dec(pottingInputs.negative.potting.empty) ?? null,
            craf4_negativepottingfilledcupweight: toNumber2Dec(pottingInputs.negative.potting.filled) ?? null,
            craf4_negativepottingnetweight: pottingNetWeights.negative.potting ?? null,
            craf4_negativebaseemptycupweight: toNumber2Dec(pottingInputs.negative.base.empty) ?? null,
            craf4_negativebasefilledcupweight: toNumber2Dec(pottingInputs.negative.base.filled) ?? null,
            craf4_negativebasenetweight: pottingNetWeights.negative.base ?? null,
            craf4_negativecatalystemptycupweight: toNumber2Dec(pottingInputs.negative.catalyst.empty) ?? null,
            craf4_negativecatalystfilledcupweight: toNumber2Dec(pottingInputs.negative.catalyst.filled) ?? null,
            craf4_negativecatalystnetweight: pottingNetWeights.negative.catalyst ?? null,
            craf4_negativeratio: ratioNegative ?? null,

            // Out-of-tolerance tracking fields
            craf4_outoftolerancecount: outOfTolLines.length,
            craf4_outoftolerancedetails: outOfTolLines.length > 0 ? outOfTolLines.join("\n") : null,
        };

        // Race createRow against a 15-second timeout
        function timeoutPromise(ms: number) {
            return new Promise((_, reject) =>
                setTimeout(() => reject(new Error(`Save timed out after ${ms / 1000} seconds.`)), ms)
            );
        }

        try {
            await Promise.race([
                dataApi.createRow("craf4_sealantlog", payload),
                timeoutPromise(15000),
            ]);
            handleClear();
            setSuccessMessage(t("successMsg"));
        } catch (err: any) {
            const errMsg =
                err && typeof err === "object" && "message" in err
                    ? err.message
                    : String(err);
            setErrorMessage(`Save failed: ${errMsg}`);
            console.error("Save failed:", err);
        } finally {
            setSubmitting(false);
        }
    }

    // Success message auto-dismiss after 5 seconds
    useEffect(() => {
        if (successMessage) {
            const timer = setTimeout(() => setSuccessMessage(""), 5000);
            return () => clearTimeout(timer);
        }
    }, [successMessage]);

    function renderTableHeader(cols: string[]) {
        return (
            <div className={styles.tblHeader}>
                <div className={styles.cellLabel}></div>
                {cols.map((col, idx) => (
                    <div className={styles.cell} key={idx}>
                        <Text size={300} weight="semibold">
                            {col}
                        </Text>
                    </div>
                ))}
            </div>
        );
    }

    function renderFrameMachineBlock({
        title,
        inputs,
        setInputs,
        frameSize,
        toleranceRows,
    }: {
        title: string;
        inputs: Record<string, { empty: string; filled: string }>;
        setInputs: (val: Record<string, { empty: string; filled: string }>) => void;
        frameSize: number | null;
        toleranceRows: { key: string; label: string }[];
    }) {
        return (
            <div className={styles.block}>
                <Text size={400} weight="semibold" block style={{ marginBottom: tokens.spacingVerticalMNudge }}>
                    {title}
                </Text>
                {renderTableHeader([
                    t("emptyCupWeight"),
                    t("filledCupWeight"),
                    t("netWeightSealent"),
                ])}
                {toleranceRows.map((row) => {
                    const empty = inputs[row.key]?.empty ?? "";
                    const filled = inputs[row.key]?.filled ?? "";
                    const net = calcNet(filled, empty);

                    let tolCheck = row.key.startsWith("long")
                        ? toleranceChecks.longFrame.check
                        : toleranceChecks.shortFrame.check;
                    const tolerance =
                        frameSize && filled !== ""
                            ? getTolerance(tolCheck, frameSize)
                            : { min: null, max: null };
                    const outOfTol = isOutOfTolerance(net, tolerance, filled);

                    return (
                        <div className={styles.tblRow} key={row.key}>
                            <div className={styles.cellLabel}>
                                <Text size={300} weight="semibold">{row.label}</Text>
                            </div>
                            <div className={styles.cell}>
                                <Input
                                    type="number"
                                    inputMode="decimal"
                                    step="0.01"
                                    value={empty}
                                    appearance="outline"
                                    size="medium"
                                    className={styles.cellInput}
                                    style={{ width: "100%" }}
                                    onChange={(_, d) => {
                                        setInputs({
                                            ...inputs,
                                            [row.key]: {
                                                ...inputs[row.key],
                                                empty: d.value,
                                            },
                                        });
                                    }}
                                    aria-label={`${row.label} ${t("emptyCupWeight")}`}
                                />
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                            <div className={styles.cell}>
                                <Input
                                    type="number"
                                    inputMode="decimal"
                                    step="0.01"
                                    value={filled}
                                    appearance="outline"
                                    size="medium"
                                    className={styles.cellInput}
                                    style={{ width: "100%" }}
                                    onChange={(_, d) => {
                                        setInputs({
                                            ...inputs,
                                            [row.key]: {
                                                ...inputs[row.key],
                                                filled: d.value,
                                            },
                                        });
                                    }}
                                    aria-label={`${row.label} ${t("filledCupWeight")}`}
                                />
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                            <div className={styles.cell} style={{ alignItems: "center" }}>
                                <div
                                    className={`${styles.netCell}${outOfTol ? " " + styles.outOfTolCell : ""}`}
                                    aria-label={`${row.label} ${t("netWeightSealent")}`}
                                    tabIndex={-1}
                                >
                                    {net === null || net === undefined || filled === ""
                                        ? ""
                                        : net.toFixed(2)}
                                </div>
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                        </div>
                    );
                })}
            </div>
        );
    }

    function renderJbSealantBlock({
        inputs,
        setInputs,
    }: {
        inputs: Record<string, { empty: string; filled: string }>;
        setInputs: (val: Record<string, { empty: string; filled: string }>) => void;
    }) {
        return (
            <div className={styles.block}>
                <Text size={400} weight="semibold" block style={{ marginBottom: tokens.spacingVerticalMNudge }}>
                    {t("junctionBoxSealant")}
                </Text>
                {renderTableHeader([
                    t("emptyCupWeight"),
                    t("filledCupWeight"),
                    t("netWeightSealent"),
                ])}
                {jbSealantRows.map((row) => {
                    const empty = inputs[row.key]?.empty ?? "";
                    const filled = inputs[row.key]?.filled ?? "";
                    const net = calcNet(filled, empty);

                    const checkKey =
                        row.key === "positive"
                            ? toleranceChecks.jbPositive.check
                            : row.key === "middle"
                            ? toleranceChecks.jbMiddle.check
                            : toleranceChecks.jbNegative.check;
                    const tolerance =
                        filled !== ""
                            ? getTolerance(checkKey, 0)
                            : { min: null, max: null };
                    const outOfTol = isOutOfTolerance(net, tolerance, filled);

                    return (
                        <div className={styles.tblRow} key={row.key}>
                            <div className={styles.cellLabel}>
                                <Text size={300} weight="semibold">{row.label}</Text>
                            </div>
                            <div className={styles.cell}>
                                <Input
                                    type="number"
                                    inputMode="decimal"
                                    step="0.01"
                                    value={empty}
                                    appearance="outline"
                                    size="medium"
                                    className={styles.cellInput}
                                    style={{ width: "100%" }}
                                    onChange={(_, d) => {
                                        setInputs({
                                            ...inputs,
                                            [row.key]: {
                                                ...inputs[row.key],
                                                empty: d.value,
                                            },
                                        });
                                    }}
                                    aria-label={`${row.label} ${t("emptyCupWeight")}`}
                                />
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                            <div className={styles.cell}>
                                <Input
                                    type="number"
                                    inputMode="decimal"
                                    step="0.01"
                                    value={filled}
                                    appearance="outline"
                                    size="medium"
                                    className={styles.cellInput}
                                    style={{ width: "100%" }}
                                    onChange={(_, d) => {
                                        setInputs({
                                            ...inputs,
                                            [row.key]: {
                                                ...inputs[row.key],
                                                filled: d.value,
                                            },
                                        });
                                    }}
                                    aria-label={`${row.label} ${t("filledCupWeight")}`}
                                />
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                            <div className={styles.cell} style={{ alignItems: "center" }}>
                                <div
                                    className={`${styles.netCell}${outOfTol ? " " + styles.outOfTolCell : ""}`}
                                    aria-label={`${row.label} ${t("netWeightSealent")}`}
                                    tabIndex={-1}
                                >
                                    {net === null || net === undefined || filled === ""
                                        ? ""
                                        : net.toFixed(2)}
                                </div>
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                        </div>
                    );
                })}
            </div>
        );
    }

    function renderPottingBlock({
        title,
        inputs,
        setInputs,
        isRatio,
        ratioValue,
        showTolerance,
    }: {
        title: string;
        inputs: Record<string, { empty: string; filled: string }>;
        setInputs: (val: Record<string, { empty: string; filled: string }>) => void;
        isRatio: boolean;
        ratioValue: number | null;
        showTolerance: boolean;
    }) {
        let ratioTolerance = showTolerance && pottingInputs
            ? getTolerance(toleranceChecks.pottingRatio.check, 0)
            : { min: null, max: null };
        const catalystFilled = inputs.catalyst.filled;
        const outOfTol =
            isRatio &&
            showTolerance &&
            isOutOfTolerance(ratioValue, ratioTolerance, catalystFilled);

        return (
            <div className={styles.block}>
                <Text size={400} weight="semibold" block style={{ marginBottom: tokens.spacingVerticalMNudge }}>
                    {title}
                </Text>
                {renderTableHeader([
                    t("emptyCupWeight"),
                    t("filledCupWeight"),
                    t("netWeightPotting"),
                ])}
                {pottingRows.map((row) => {
                    const empty = inputs[row.key]?.empty ?? "";
                    const filled = inputs[row.key]?.filled ?? "";
                    const net = calcNet(filled, empty);
                    return (
                        <div className={styles.tblRow} key={row.key}>
                            <div className={styles.cellLabel}>
                                <Text size={300} weight="semibold">{row.label}</Text>
                            </div>
                            <div className={styles.cell}>
                                <Input
                                    type="number"
                                    inputMode="decimal"
                                    step="0.01"
                                    value={empty}
                                    appearance="outline"
                                    size="medium"
                                    className={styles.cellInput}
                                    style={{ width: "100%" }}
                                    onChange={(_, d) => {
                                        setInputs({
                                            ...inputs,
                                            [row.key]: {
                                                ...inputs[row.key],
                                                empty: d.value,
                                            },
                                        });
                                    }}
                                    aria-label={`${row.label} ${t("emptyCupWeight")}`}
                                />
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                            <div className={styles.cell}>
                                <Input
                                    type="number"
                                    inputMode="decimal"
                                    step="0.01"
                                    value={filled}
                                    appearance="outline"
                                    size="medium"
                                    className={styles.cellInput}
                                    style={{ width: "100%" }}
                                    onChange={(_, d) => {
                                        setInputs({
                                            ...inputs,
                                            [row.key]: {
                                                ...inputs[row.key],
                                                filled: d.value,
                                            },
                                        });
                                    }}
                                    aria-label={`${row.label} ${t("filledCupWeight")}`}
                                />
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                            <div className={styles.cell} style={{ alignItems: "center" }}>
                                <div className={styles.netCell}
                                    aria-label={`${row.label} ${t("netWeightPotting")}`}
                                    tabIndex={-1}
                                >
                                    {net === null || net === undefined || filled === ""
                                        ? ""
                                        : net.toFixed(2)}
                                </div>
                                <Text size={200} className={styles.cellUnit}>
                                    {t("gUnit")}
                                </Text>
                            </div>
                        </div>
                    );
                })}
                <Divider style={{ marginTop: tokens.spacingVerticalXS }} />
                <div style={{ display: "flex", flexDirection: "row", alignItems: "center", marginTop: tokens.spacingVerticalM }}>
                    <Text size={300} weight="semibold" block style={{ minWidth: 80 }}>
                        {t("ratio")}
                    </Text>
                    <div
                        className={`${styles.ratioCell}${outOfTol ? " " + styles.outOfTolCell : ""}`}
                        aria-label={`${title} Ratio`}
                        style={{ marginLeft: tokens.spacingHorizontalL }}
                    >
                        {isRatio
                            ? catalystFilled === "" || ratioValue === null
                                ? ""
                                : formatRatio(ratioValue)
                            : ""}
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div
            className={styles.root}
            dir={isRTL ? "rtl" : "ltr"}
            style={{ direction: isRTL ? "rtl" : "ltr" }}
        >
            {/* Hide number input spinner arrows globally */}
            <style>
                {`
                input[type="number"]::-webkit-outer-spin-button,
                input[type="number"]::-webkit-inner-spin-button {
                    -webkit-appearance: none;
                    margin: 0;
                }
                input[type="number"] {
                    -moz-appearance: textfield;
                }
                `}
            </style>
            <div className={styles.paper}>
                <div className={styles.titleRow}>
                    <Text size={400} weight="semibold">
                        {t("lauland")}
                    </Text>
                    <Text
                        size={600}
                        weight="semibold"
                        block
                        style={{ textAlign: "center" }}
                    >
                        {t("sheetTitle")}
                    </Text>
                    <div style={{ display: "flex", flexDirection: "column", textAlign: "right" }}>
                        <Text size={300} weight="medium" block>
                            {t("formNumber")}
                        </Text>
                        <Text size={300} weight="regular" block>
                            {t("revisionDate")}
                        </Text>
                    </div>
                </div>
                <div className={styles.headerRow}>
                    <div className={styles.headerGroup}>
                        <Text size={400} weight="semibold" block>
                            {t("line")}
                        </Text>
                        <select
                            className={styles.htmlSelect}
                            aria-label={t("selectLine")}
                            value={line !== null ? String(line) : ""}
                            onChange={e => {
                                const val = e.target.value;
                                setLine(val === "" ? null : Number(val));
                            }}
                        >
                            <option value="">{t("selectLine")}</option>
                            {lineOptions.map(l => (
                                <option key={l} value={l}>{l}</option>
                            ))}
                        </select>
                    </div>
                    <div className={styles.headerGroup}>
                        <Text size={400} weight="semibold" block>
                            {t("frameSize")}
                        </Text>
                        <select
                            className={styles.htmlSelect}
                            aria-label={t("selectSize")}
                            value={frameSize !== null ? String(frameSize) : ""}
                            onChange={e => {
                                const val = e.target.value;
                                setFrameSize(val === "" ? null : Number(val));
                            }}
                        >
                            <option value="">{t("selectSize")}</option>
                            {frameSizeOptions.map(s => (
                                <option key={s} value={String(s)}>{s}</option>
                            ))}
                        </select>
                    </div>
                    <div className={styles.headerGroup}>
                        <Text size={400} weight="semibold" block>
                            {t("date")}
                        </Text>
                        <input
                            type="date"
                            value={date}
                            onChange={e => setDate(e.target.value)}
                            aria-label={t("selectDate")}
                            style={{
                                minWidth: 120,
                                padding: "6px 8px",
                                borderRadius: tokens.borderRadiusSmall,
                                border: `1px solid ${tokens.colorNeutralStroke1}`,
                                fontSize: tokens.fontSizeBase400,
                                fontFamily: tokens.fontFamilyBase,
                                background: tokens.colorNeutralBackground1,
                                color: tokens.colorNeutralForeground1,
                            }}
                        />
                    </div>
                    <div className={styles.headerGroup}>
                        <Text size={400} weight="semibold" block>
                            {t("shift")}
                        </Text>
                        <select
                            className={styles.htmlSelect}
                            aria-label={t("selectShift")}
                            value={shift !== null ? shift : ""}
                            onChange={e => {
                                const val = e.target.value;
                                setShift(val === "" ? null : val);
                            }}
                        >
                            <option value="">{t("selectShift")}</option>
                            {shiftOptions.map(s => (
                                <option key={s} value={s}>{s}</option>
                            ))}
                        </select>
                    </div>
                </div>
                <Text className={styles.sectionTitle}>{t("sealantCalculations")}</Text>
                <div className={styles.blockRow}>
                    {renderFrameMachineBlock({
                        title: t("frameMachine1"),
                        inputs: fm1Inputs,
                        setInputs: (val) => setFm1Inputs(val),
                        frameSize: frameSize,
                        toleranceRows: frameSealantRows,
                    })}
                    {renderFrameMachineBlock({
                        title: t("frameMachine2"),
                        inputs: fm2Inputs,
                        setInputs: (val) => setFm2Inputs(val),
                        frameSize: frameSize,
                        toleranceRows: frameSealantRows,
                    })}
                    {renderJbSealantBlock({
                        inputs: jbInputs,
                        setInputs: (val) => setJbInputs(val),
                    })}
                </div>
                <Text className={styles.sectionTitle}>{t("junctionBoxPotting")}</Text>
                <div className={styles.blockRow}>
                    {renderPottingBlock({
                        title: t("positiveTerminal"),
                        inputs: pottingInputs.positive,
                        setInputs: (val) =>
                            setPottingInputs({
                                ...pottingInputs,
                                positive: val,
                            }),
                        isRatio: true,
                        ratioValue: calcRatio(
                            calcNet(
                                pottingInputs.positive.base.filled,
                                pottingInputs.positive.base.empty
                            ),
                            calcNet(
                                pottingInputs.positive.catalyst.filled,
                                pottingInputs.positive.catalyst.empty
                            )
                        ),
                        showTolerance: true,
                    })}
                    {renderPottingBlock({
                        title: t("middleTerminal"),
                        inputs: pottingInputs.middle,
                        setInputs: (val) =>
                            setPottingInputs({
                                ...pottingInputs,
                                middle: val,
                            }),
                        isRatio: true,
                        ratioValue: calcRatio(
                            calcNet(
                                pottingInputs.middle.base.filled,
                                pottingInputs.middle.base.empty
                            ),
                            calcNet(
                                pottingInputs.middle.catalyst.filled,
                                pottingInputs.middle.catalyst.empty
                            )
                        ),
                        showTolerance: true,
                    })}
                    {renderPottingBlock({
                        title: t("negativeTerminal"),
                        inputs: pottingInputs.negative,
                        setInputs: (val) =>
                            setPottingInputs({
                                ...pottingInputs,
                                negative: val,
                            }),
                        isRatio: true,
                        ratioValue: calcRatio(
                            calcNet(
                                pottingInputs.negative.base.filled,
                                pottingInputs.negative.base.empty
                            ),
                            calcNet(
                                pottingInputs.negative.catalyst.filled,
                                pottingInputs.negative.catalyst.empty
                            )
                        ),
                        showTolerance: true,
                    })}
                </div>
                <div className={styles.btnRow}>
                    <Button
                        appearance="primary"
                        disabled={!isReadyToSubmit}
                        onClick={handleSubmit}
                    >
                        {t("submit")}
                    </Button>
                    <Button
                        appearance="secondary"
                        onClick={handleClear}
                        icon={<DismissRegular fontSize="1em" />}
                    >
                        {t("clear")}
                    </Button>
                </div>
                {/* Success/Error message area directly below the buttons */}
                {(successMessage || errorMessage) && (
                    <div>
                        {successMessage && (
                            <div className={styles.message}>
                                {successMessage}
                            </div>
                        )}
                        {errorMessage && (
                            <div className={styles.errorMessage}>
                                <InfoRegular fontSize="1.25em" style={{ marginRight: 8, verticalAlign: "middle" }} />
                                {errorMessage}
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default GeneratedComponent;